"use client";
import MainLayout from "@/src/components/Main-Layout/Layout/Main-layout";
import Table from "@/src/components/Table/Table";
import { useCoursesState } from "../courses/useCoursesState";
import { UNIVERSITY_SECTION_TYPE } from "@/src/types/university-section.type";
import ModalBox from "@/src/components/Modal/Modal";

export default function CoursesManaged() {
    const {closeDeleteModal,
        showModal,
        course,handleDeleteCourse,openDeleteModal,router,courseData} = useCoursesState();
     return (
        <>
        <MainLayout>
           <Table 
           data={course ?? []}
           type={UNIVERSITY_SECTION_TYPE.COURSES}
           addBtn={()=>router.push("/add-course")}
           openDeleteModal={openDeleteModal}
           handleEdit={(id)=>router.push(`/edit-course/${id}`)}/>
        </MainLayout>

         {showModal && (
                 <ModalBox
                   confirmText="Delete"
                   message="Are you really  want to  delete Course"
                   onCancel={closeDeleteModal}
                   title="Delete Course"
                   onConfirm={handleDeleteCourse}
                 />
               )}
        </>
    )
}